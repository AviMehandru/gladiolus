from piazza_api import Piazza
import json
import time
import random
import datetime
import os

def setup(): 
    print('Starting setup')
    global p 
    global mySecretsDict
    global previousDatesDict
    global course

    global secretsPath
    global postsDirectory

    secretsPath = '../secrets/loginDetails.json'
    postsDirectory = '../posts/'

    p = Piazza()

    with open(secretsPath, 'r', encoding = 'utf-8') as f:
        mySecretsDict = json.load(f)

    p.user_login(email = mySecretsDict['email'], password = mySecretsDict['password'])

    course = p.network(mySecretsDict['course'])
    print('Ending setup')

def pullAll(): 
    print('Starting full pull')

    os.makedirs(postsDirectory, exist_ok = True)

    myFeed = course.get_feed(limit = 999999, offset = 0)

    feedDates = {}

    for i in myFeed['feed']: 
        feedDates[i['nr']] = i['modified']

    print('Pulled feed for full pull')

    dictOfPosts = {}

    postCounter = 1

    for i in course.iter_all_posts(): 
        dictOfPosts[i['nr']] = i
        time.sleep(random.randint(1, 20) / 10)
        if ((postCounter % 10) == 0): 
            print(postCounter)
        postCounter += 1

    print(f'Number of posts: {len(dictOfPosts)}')

    for i in dictOfPosts: 
        with open(f'{postsDirectory}post_{i}', 'w', encoding = 'utf-8') as f: 
            json.dump(dictOfPosts[i], f, indent = 4)
        
        try: 
            with open(f'{postsDirectory}lastUpdated.json', 'r', encoding = 'utf-8') as f: 
                oldLastUpdatedDict = json.load(f)
        except FileNotFoundError: 
            oldLastUpdatedDict = {}
        
        oldLastUpdatedDict[str(i)] = feedDates.get(i, None)

        with open(f'{postsDirectory}lastUpdated.json', 'w', encoding = 'utf-8') as f: 
            json.dump(oldLastUpdatedDict, f, indent = 4)

    print('Saved all posts')

def pullFeed(): 
    print('Starting feed pull')

    try: 
        with open(f'{postsDirectory}lastUpdated.json', 'r', encoding = 'utf-8') as f:
            previousDatesDict = json.load(f)
    except FileNotFoundError: 
        previousDatesDict = {}
    
    myFeed = course.get_feed(limit = 999999, offset = 0)

    processedFeed = {}

    for i in myFeed['feed']: 
        processedFeed[i['nr']] = i['modified']

    fetchList = []

    for i in processedFeed: 
        if (processedFeed.get(i, None) != previousDatesDict.get(str(i), None)): 
            fetchList.append(i)

    postCounter = 1

    dictOfPosts = {}

    print('Pulled and filtered')

    if len(fetchList) != 0: 
        for i in fetchList: 
            dictOfPosts[i] = course.get_post(i)
            time.sleep(random.randint(1, 20) / 10)
            print(postCounter)
            postCounter += 1

        for i in dictOfPosts: 
            with open(f'{postsDirectory}post_{i}', 'w', encoding = 'utf-8') as f: 
                json.dump(dictOfPosts[i], f, indent = 4)

            previousDatesDict[str(i)] = processedFeed[i]

        with open(f'{postsDirectory}lastUpdated.json', 'w', encoding = 'utf-8') as f: 
            json.dump(previousDatesDict, f, indent = 4)

    print('Saved feed')

def main(): 
    pullPostsDate = datetime.datetime.now().replace(second = 0, microsecond = 0)
    pullFeedDate = datetime.datetime.now().replace(second = 0, microsecond = 0)

    while True: 
        try: 
            setup()
            break
        except Exception as e: 
            print('An error occurred:', e)
            time.sleep(60)
    
    while True: 
        try: 
            if datetime.datetime.now() >= pullPostsDate: 
                pullAll()

                daysToSunday = 6 - datetime.datetime.now().weekday()

                if daysToSunday <= 0:
                    daysToSunday += 7
                
                pullPostsDate = (datetime.datetime.now() + datetime.timedelta(days = daysToSunday)).replace(hour = random.randint(5, 12), minute = random.randint(1, 59))
            
                print('while True pulling all posts')

            if datetime.datetime.now().replace(second = 0, microsecond = 0) >= pullFeedDate.replace(second = 0, microsecond = 0): 
                pullFeed()

                pullFeedDate = datetime.datetime.now() + datetime.timedelta(minutes = random.randint(1, 10))
        
                print('while True pulling feed')

        except Exception as e: 
            print('An error occurred:', e)
            time.sleep(60)
            try:
                setup()
            except Exception as d:
                print('An error occurred:', d)

        time.sleep(30)

if __name__ == '__main__': 
    main()
